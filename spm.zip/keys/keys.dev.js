module.exports = {
    BASE_URL: 'localhost:3000',
    HOST: 'localhost',
    EMAIL_USER: 'kirill.deykun1@gmail.com',
    EMAIL_PASS: 'Leonardo@2801',
    EMAIL_HOST: 'smtp.gmail.com'
}